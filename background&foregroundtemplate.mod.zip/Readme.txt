请随意替换图片，增加或删除对应的图片名即可
需要decorations_zh或decorations

Please feel free to replace the image by adding or deleting the corresponding image name
decorations_zh or decorations needed

credits:
miyako4828 for modloadering

