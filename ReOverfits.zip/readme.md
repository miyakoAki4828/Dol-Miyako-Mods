开外衣、外裤、头套槽。Overfits更新版，已取得原作者授权。

适配游戏0.4.5.3及以上。

不兼容的MOD：

Overfits

外套槽MOD

LowerSkyBox

猫教&Mamon&miyako4828